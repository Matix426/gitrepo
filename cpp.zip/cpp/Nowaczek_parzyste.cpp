/*
 * parzyste.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    for(int i = 0; i < 100; i += 2) 
    {
        int a;
        cout << "Podaj a: ";
        i = 2;
    
        if (a=i)
            cout<<"A jest parzyste"<<endl;
        else
            cout<<"A jest nieparzyste"<<endl;
    }
            
    
	return 0;
}


