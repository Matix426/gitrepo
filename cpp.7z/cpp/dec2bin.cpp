/*
 * dec2bin.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int liczba = 120;
    do
    { 
        ; 
        
    }while(liczba > 0);
    for (int j = i - 1; j >= 0; j--)
    {
         cout << reszty [j];
    } 
    int j = i - 1;
        while(j>=0)
        {
            cout<<reszty[j];
            j--;
        }
	
	return 0;
}

