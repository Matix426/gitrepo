/*
 * petla_5.cpp
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int x;
    cin>>x;
    for (int i=0;i <=x;i++)
    cout <<i*i<<endl;

    return 0;
}
